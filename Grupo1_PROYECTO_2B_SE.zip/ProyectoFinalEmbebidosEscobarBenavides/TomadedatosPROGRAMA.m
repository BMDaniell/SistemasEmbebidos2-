%% Preparar medida
close;
clc;
clear;
tmax = 50/9; % tiempo de captura en s
rate = 18; % resultado experimental (comprobar)
f = figure('Name','Captura');
ej = axes('XLim',[0 tmax],'YLim',[0 5]);
l1 = line(nan,nan,'Color','r','LineWidth',2);
l2 = line(nan,nan,'Color','b','LineWidth',2);

xlabel('Tiempo (s)')
ylabel('Voltaje (V)')
title('Captura de voltaje en tiempo real con Arduino')
grid on
hold on
%arduino
clear a;
a = arduino('COM3', 'Uno');
% parámetros de medidas
v1 = zeros(1,tmax*rate);
v2 = zeros(1,tmax*rate);
i=1;
t=0;
tic
while t<tmax
    t=toc;
    flex=100*readVoltage(a,'A0');
    mq=100*readVoltage(a,'A1');
    v1(i)=flex*5/1024;
    v2(i)=mq*5/1024;
    x = linspace(0,i/rate,i);
    set(l1,'YData',5*v1(1:i)/0.25,'XData',x);
    set(l2,'YData',10*v2(1:i),'XData',x);
    drawnow
%     if flex>30 && mq > 25
%         for k = 1:10
%           writeDigitalPin(a, 'D11', 1);
%           writeDigitalPin(a, 'D10', 1);
%           pause(0.1);
%           writeDigitalPin(a, 'D11', 0);
%           writeDigitalPin(a, 'D10', 0);
%           pause(0.1);
%         end
%     end
    i=i+1;
end
clc;
fprintf('%g s de captura a %g cap/s \n',t,i/t);

%% Filtro mediana escogido
figure(2)
y = medfilt1(v1);
y2 = medfilt1(v2);
subplot(2,1,1)
plot(x,v1(1:i-1))
title('Señal Recibida por el mq7')
grid on 
hold on
plot(x,y(1:i-1),'r--')
xlabel('Tiempo (s)')
ylabel('Voltaje (V)')
legend('Señal Entrada','Señal Filtrada o Suavizada')
subplot(2,1,2)
plot(x,v2(1:i-1))
title('Señal Recibida por el Sensor de Gas MQ135')
grid on
hold on
plot(x,y2(1:i-1),'r--')
xlabel('Tiempo (s)')
ylabel('Voltaje (V)')
legend('Señal Entrada','Señal Filtrada o Suavizada')
grid on

%% Calculo de la SNR
SN1=snr(v1,y);
SN2=snr(v2,y2);
disp(['La SNR de la señal recibida por el MQ7 es: ', num2str(SN1)])
disp(['La SNR de la señal recibida por el MQ135 es: ', num2str(SN2)])